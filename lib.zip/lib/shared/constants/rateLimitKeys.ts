export const RATE_LIMIT_KEYS = {
  SIGNIN: 'signin',
  REGISTER: 'register',
  PASSWORD_RESET: 'password-reset',
} as const;
