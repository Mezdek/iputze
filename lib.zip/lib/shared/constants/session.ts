export const SESSION_COOKIE_NAMES = [
  '__Secure-next-auth.session-token',
  'next-auth.session-token',
] as const;

export const REFRESH_TOKEN_NAME = 'refreshToken';
